package Avance.proyecto.grupo02.clase.deportista;
public class AvanceProyeectoGrupo02ClaseDeportista {
public static void main(String[] args) {
    
        // TODO code application logic here
    }
    
}
